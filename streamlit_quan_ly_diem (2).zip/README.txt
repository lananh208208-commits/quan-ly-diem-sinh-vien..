# QUẢN LÝ ĐIỂM SINH VIÊN-

## Chạy trên máy tính
1. Cài Python nếu máy chưa có.
2. Mở Terminal/CMD trong thư mục này.
3. Chạy: `pip install -r requirements.txt`
4. Chạy: `streamlit run app.py`

## Đưa ứng dụng lên mạng
1. Đăng nhập GitHub và tạo một repository mới.
2. Tải `app.py` và `requirements.txt` lên repository.
3. Mở https://share.streamlit.io/ và đăng nhập.
4. Chọn **Create app**, chọn repository, branch (thường là `main`) và file chính `app.py`.
5. Nhấn **Deploy**. Sau khi triển khai xong, sao chép URL Streamlit được cấp để gửi giáo viên.

Trước khi nộp, hãy thay `ĐIỀN_MSSV_CỦA_BẠN` ở cuối file `app.py` bằng MSSV thật.
Điểm tổng kết đang dùng công thức: 20% chuyên cần + 30% giữa kỳ + 50% cuối kỳ.
Dữ liệu sinh viên được lấy từ ví dụ trong tệp bài tập đã cung cấp.
